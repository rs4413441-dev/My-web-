# MyAppStore — शुरुआती वेबसाइट फ़ाइलें

## फ़ाइलें
- `index.html` — मोबाइल-फ्रेंडली ऐप सूची, खोज, कैटेगरी फ़िल्टर और डाउनलोड लिंक।
- `apps.json` — ऐप सूची का डेटा।
- `admin.html` — सुरक्षित एडमिन बनाने के निर्देश; यह जानबूझकर नकली/असुरक्षित लॉगिन नहीं देता।

## ऐप जोड़ना
1. `apps.json` खोलें।
2. डेमो रिकॉर्ड की जानकारी बदलें।
3. `downloadUrl` में वास्तविक, सार्वजनिक रूप से डाउनलोड होने वाला APK URL डालें।
4. यदि URL खाली है, तो डाउनलोड बटन निष्क्रिय दिखेगा।
5. JSON में कॉमा और उद्धरण सही रखें। किसी भी असली APK को अपलोड किए बिना केवल वेबसाइट से डाउनलोड संभव नहीं होगा।

## मुफ़्त होस्टिंग: GitHub Pages (स्थिर वेबसाइट के लिए)
1. GitHub अकाउंट बनाएँ/लॉगिन करें: https://github.com/
2. नया **Public** repository बनाएँ, उदाहरण `myappstore`.
3. इस ZIP की फ़ाइलें repository के root में अपलोड करें (`index.html`, `apps.json`, `admin.html`)।
4. Repository → **Settings** → **Pages** खोलें।
5. **Deploy from a branch** चुनें, branch `main` और folder `/ (root)` चुनें, फिर Save करें।
6. कुछ मिनट बाद GitHub Pages में दिखने वाला URL खोलें।

## बहुत ज़रूरी सीमाएँ
- GitHub Pages केवल static hosting है। यह सुरक्षित admin login, database या APK upload backend नहीं देता।
- GitHub Pages को बड़े APK फ़ाइलों की फ़ाइल-होस्टिंग के रूप में इस्तेमाल न करें; फ़ाइलों के लिए उपयुक्त storage/download provider इस्तेमाल करें।
- GitHub Pages के नियमों में commercial software/SaaS के रूप में उपयोग पर प्रतिबंध हैं। अपनी वेबसाइट का उपयोग करने से पहले वर्तमान नीति पढ़ें: https://docs.github.com/en/pages/getting-started-with-github-pages/github-pages-limits
- सार्वजनिक repository की सभी फ़ाइलें इंटरनेट पर दिख सकती हैं। इसमें secrets, पासवर्ड या निजी APK न रखें।
- `admin.html` सुरक्षा नियंत्रण नहीं है। वास्तविक admin के लिए backend authentication, role authorization और सुरक्षित storage rules अनिवार्य हैं।
- APK केवल अपने बनाए हुए या वितरण की अनुमति वाले ऐप के लिए प्रकाशित करें। डाउनलोड पेज पर डेवलपर, version और checksum जैसी जानकारी देना बेहतर है।
